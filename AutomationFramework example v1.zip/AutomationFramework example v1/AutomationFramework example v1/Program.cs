﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationFramework_example_v1
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    Drivers.setDriver(Drivers.DriverType.CHROME);
        //    Drivers.setDriverURL("https://aarp-test.kanacloud.com/GTConnect/UnifiedAcceptor/AARPDesktop.Main");

        //}
    }
}
