﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationFramework_example_v1
{
    class Controls
    {
        //public static void findControlByXpath(string Xpath)
        //{
        //    Environment.Control = Environment.Driver.FindElement(By.XPath(Xpath));
        //}

        //public static void findControlById(string id)
        //{
        //    Environment.Control = Environment.Driver.FindElement(By.Id(id));
        //}

        //public static void findControlByCssSelector(string css)
        //{
        //    Environment.Control = Environment.Driver.FindElement(By.CssSelector(css));
        //}


    }
}
